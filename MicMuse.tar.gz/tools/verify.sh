#!/system/bin/sh
# 注入链路体检：模块是否部署 / ZygiskNext 是否在 / 抓取 MicMuse 日志
echo "== 1. 模块 =="
su -c 'ls /data/adb/modules/micmuse 2>/dev/null && cat /data/adb/modules/micmuse/targets.conf 2>/dev/null' || echo "未部署"
echo
echo "== 2. Zygisk 提供者 =="
found=0
for d in /data/adb/modules/*/; do
  [ -f "$d/module.prop" ] || continue
  if grep -q -i -E "zygisk" "$d/module.prop" 2>/dev/null; then
    echo "找到: $(basename $d)"; found=1
  fi
done
[ $found -eq 0 ] && echo "没找到 ZygiskNext —— 注入不会生效"
echo
echo "== 3. 目标进程是否在跑 =="
for p in $(su -c "grep -v '^#' /data/adb/modules/micmuse/targets.conf 2>/dev/null" | tr -d ' '); do
  [ -n "$p" ] || continue
  n=$(su -c "ps -A 2>/dev/null | grep -c $p" | tr -d ' ')
  echo "$p -> 进程数 $n"
done
echo
echo "== 4. 抓 40 秒 MicMuse 日志（现在去游戏里开语音）=="
su -c 'timeout 40 logcat -s MicMuse 2>/dev/null' || su -c 'logcat -d -s MicMuse | tail -30'
echo
echo "== 5. App 侧日志 =="
su -c 'logcat -d -s MicMuse/Engine | tail -15'
