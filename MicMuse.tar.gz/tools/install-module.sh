#!/system/bin/sh
# 把构建好的模块目录部署到 /data/adb/modules/micmuse（需要 root）
set -e
HERE=$(cd "$(dirname "$0")/.." && pwd)
SRC="$HERE/module/build/out"
[ -d "$SRC" ] || { echo "没找到 $SRC，先构建模块"; exit 1; }

echo "将部署到 /data/adb/modules/micmuse："
ls -R "$SRC" | head -20
su -c "rm -rf /data/adb/modules/micmuse && mkdir -p /data/adb/modules/micmuse && cp -r $SRC/. /data/adb/modules/micmuse/ && chmod -R 755 /data/adb/modules/micmuse && ls -l /data/adb/modules/micmuse"
echo
echo "已部署。确认已安装 ZygiskNext 后重启手机；"
echo "编辑目标包名: su -c 'vi /data/adb/modules/micmuse/targets.conf'"
