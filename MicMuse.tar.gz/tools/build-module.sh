#!/system/bin/sh
# 在 AndroidIDE 终端里构建 Zygisk 模块（会自动拉 ZygiskNDK、找 NDK）
set -e
HERE=$(cd "$(dirname "$0")/.." && pwd)
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/android-sdk}}"
NDK="${NDK:-$SDK/ndk/27.0.12077973}"
[ -d "$NDK" ] || { echo "找不到 NDK: $NDK"; echo "先运行: sdkmanager \"ndk;27.0.12077973\""; exit 1; }

ZY="$HERE/ZygiskNDK"
[ -d "$ZY" ] || git clone --depth 1 https://github.com/Dr-TSNG/ZygiskNDK "$ZY"

command -v cmake >/dev/null 2>&1 || { echo "缺 cmake，先运行: pkg install cmake"; exit 1; }

NDK="$NDK" ZYGISK_NDK="$ZY" sh "$HERE/module/build.sh"
echo
echo "产物目录: $HERE/module/build/out"
