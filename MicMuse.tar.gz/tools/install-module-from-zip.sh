#!/system/bin/sh
# 用法: sh install-module-from-zip.sh /sdcard/Download/micmuse-module.zip
ZIP="$1"
[ -n "$ZIP" ] || { echo "用法: sh $0 /sdcard/Download/micmuse-module.zip"; exit 1; }
[ -f "$ZIP" ] || { echo "找不到文件: $ZIP"; exit 1; }
TMP=/data/local/tmp/micmuse-mod
su -c "rm -rf $TMP && mkdir -p $TMP && cd $TMP && unzip -o '$ZIP' >/dev/null && rm -rf /data/adb/modules/micmuse && mkdir -p /data/adb/modules/micmuse && cp -r $TMP/. /data/adb/modules/micmuse/ && chmod -R 755 /data/adb/modules/micmuse && echo '--- 已部署 ---' && ls -lR /data/adb/modules/micmuse | head -20"
echo
echo "确认已装 ZygiskNext，然后重启手机。"
