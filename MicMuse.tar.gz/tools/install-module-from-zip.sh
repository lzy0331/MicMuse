#!/system/bin/sh
# 部署注入模块。支持两种 zip：
#   1) 从 GitHub 下载的 artifact 包（里面还有一层 micmuse-module.zip）
#   2) 直接就是模块目录内容的 zip（含 module.prop / zygisk/arm64.so）
# 用法: sh install-module-from-zip.sh /sdcard/Download/micmuse-module.zip
ZIP="$1"
[ -n "$ZIP" ] || { echo "用法: sh $0 <zip 路径>"; exit 1; }
[ -f "$ZIP" ] || { echo "找不到: $ZIP"; exit 1; }

TMP=/data/local/tmp/mm_zip
su -c "rm -rf $TMP && mkdir -p $TMP && cd $TMP && unzip -o '$ZIP' >/dev/null"

# 如果是 artifact 包，解出内层 zip 再解压
inner=$(su -c "ls $TMP/*.zip 2>/dev/null | head -1")
if [ -n "$inner" ]; then
  echo "检测到内层 zip: $inner"
  su -c "cd $TMP && unzip -o '$inner' >/dev/null"
fi

if ! su -c "test -f $TMP/module.prop"; then
  echo "解压后没找到 module.prop，内容如下："
  su -c "ls -R $TMP | head -20"
  exit 2
fi

su -c "rm -rf /data/adb/modules/micmuse && mkdir -p /data/adb/modules/micmuse && cp -r $TMP/. /data/adb/modules/micmuse/ && rm -f /data/adb/modules/micmuse/*.zip && chmod -R 755 /data/adb/modules/micmuse"
echo "--- 部署内容 ---"
su -c "ls -lR /data/adb/modules/micmuse | head -20"
echo
echo "目标应用（targets.conf）:"
su -c "grep -v '^#' /data/adb/modules/micmuse/targets.conf 2>/dev/null"
echo
echo "如果还没装 ZygiskNext，先去装；然后重启手机。"
