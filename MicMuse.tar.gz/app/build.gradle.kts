plugins { id("com.android.application") }

android {
    namespace = "com.dsh.micmuse"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dsh.micmuse"
        minSdk = 26
        targetSdk = 29
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    packaging {
        resources.excludes += setOf("META-INF/*.kotlin_module")
    }
}
