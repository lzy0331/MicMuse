package com.dsh.micmuse;

/**
 * 流式线性插值重采样 + 声道适配（s16le 交错）。
 *
 * 做法：维护一个"历史帧"hist（目标声道数的 float 帧），每次把 hist 和本次输入拼成虚拟数组 V，
 * 用 V=0 处的 pos 做插值；处理完把仍然需要的帧留作新的 hist，并相应推进 pos。
 * 这样跨 buffer 的插值相位是连续的，不会每 20ms 产生一次咔哒声。
 */
public final class Resampler {

    private final int srcCh;
    private final int dstCh;
    private final double step;   // 源帧 / 目标帧

    private final float[] hist;  // 上一轮留下的帧
    private double pos;          // 相对于 hist 的浮点位置：0 = 正好在 hist，1 = 第一个新样本
    private boolean inited;

    public Resampler(int srcRate, int srcCh, int dstRate, int dstCh) {
        this.srcCh = Math.max(1, srcCh);
        this.dstCh = Math.max(1, dstCh);
        this.hist = new float[this.dstCh];
        this.step = (double) Math.max(1, srcRate) / (double) Math.max(1, dstRate);
        this.pos = 1.0;
    }

    public Resampler reset(int srcRate, int dstRate) {
        return new Resampler(srcRate, srcCh, dstRate, dstCh);
    }

    public int dstChannels() { return dstCh; }

    /** 输入的源帧转成目标声道的 float，写入 V[1+i]。 */
    private void convert(short[] in, int frames, float[] v) {
        for (int i = 0; i < frames; i++) {
            int base = i * srcCh;
            int out = (1 + i) * dstCh;
            if (dstCh == 1) {
                float s = 0f;
                for (int c = 0; c < srcCh; c++) s += in[base + c];
                if (srcCh > 1) s /= srcCh;
                v[out] = s;
            } else if (srcCh == 1) {
                float s = in[base];
                for (int c = 0; c < dstCh; c++) v[out + c] = s;
            } else {
                for (int c = 0; c < dstCh; c++) {
                    v[out + c] = in[base + Math.min(c, srcCh - 1)];
                }
            }
        }
    }

    /**
     * @param in     交错 s16le 源数据
     * @param frames 源帧数
     * @param gain   线性增益
     * @return 交错 s16le 目标数据（可能为 0 长度）
     */
    public byte[] process(short[] in, int frames, float gain) {
        if (frames <= 0) return new byte[0];

        float[] v = new float[(frames + 1) * dstCh];
        System.arraycopy(hist, 0, v, 0, dstCh);
        convert(in, frames, v);
        inited = true;

        int maxOut = (int) Math.ceil(frames / step) + 3;
        short[] out = new short[maxOut * dstCh];
        int outFrames = 0;

        while (true) {
            int ip = (int) Math.floor(pos);
            if (ip + 1 > frames) break;      // 需要 V[ip+1]，超出本次输入
            if (outFrames >= maxOut) break;
            double frac = pos - ip;
            int a = ip * dstCh, b = (ip + 1) * dstCh, o = outFrames * dstCh;
            for (int c = 0; c < dstCh; c++) {
                float av = v[a + c], bv = v[b + c];
                int s = Math.round((av + (bv - av) * (float) frac) * gain);
                if (s > 32767) s = 32767; else if (s < -32768) s = -32768;
                out[o + c] = (short) s;
            }
            outFrames++;
            pos += step;
        }

        // 把 pos 之前用不到的帧推进掉，保留 floor(pos) 处的帧作为下次的 hist
        int keep = (int) Math.floor(pos);
        if (keep > frames) keep = frames;
        if (keep < 0) keep = 0;
        System.arraycopy(v, keep * dstCh, hist, 0, dstCh);
        pos -= keep;

        byte[] bytes = new byte[outFrames * dstCh * 2];
        int k = 0;
        for (int i = 0; i < outFrames * dstCh; i++) {
            short s = out[i];
            bytes[k++] = (byte) (s & 0xFF);
            bytes[k++] = (byte) ((s >> 8) & 0xFF);
        }
        return bytes;
    }

    public boolean hasInput() { return inited; }
}
