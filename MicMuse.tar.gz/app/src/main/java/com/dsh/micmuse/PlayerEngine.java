package com.dsh.micmuse;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * 播放引擎：解码本地音频 -> 重采样到注入模块要求的格式 -> 通过 127.0.0.1:PORT 推给模块。
 * 没有客户端连接时不推进播放（避免"歌跑掉了人还没进游戏"）。
 */
public final class PlayerEngine {

    private static final String TAG = "MicMuse/Engine";
    private static final String PREF = "micmuse";
    private static final String KEY_TRACKS = "tracks";
    private static final int QUEUE_PACKETS = 40;

    public interface Listener {
        void onStateChanged();
        void onTrackChanged(int index, String name);
        void onError(String msg);
    }

    private final Context appCtx;
    private final Handler main = new Handler(Looper.getMainLooper());

    private final List<Uri> tracks = Collections.synchronizedList(new ArrayList<>());
    private final List<String> names = Collections.synchronizedList(new ArrayList<>());

    private volatile int index = 0;
    private volatile boolean playing = false;
    private volatile boolean loop = true;
    private volatile float volume = 1.0f;
    private volatile boolean running = false;

    private volatile Socket client;
    private volatile OutputStream clientOut;
    private volatile int dstRate = 48000;
    private volatile int dstCh = 1;

    private final ArrayBlockingQueue<byte[]> queue = new ArrayBlockingQueue<>(QUEUE_PACKETS);
    private Thread acceptThread;
    private Thread decodeThread;
    private Listener listener;

    public PlayerEngine(Context ctx) {
        this.appCtx = ctx.getApplicationContext();
        loadTracks();
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    private void notifyState() {
        Listener l = listener;
        if (l != null) main.post(l::onStateChanged);
    }

    // ---------------- 曲目管理 ----------------

    public int trackCount() { return tracks.size(); }

    public String trackName(int i) {
        synchronized (names) {
            return (i >= 0 && i < names.size()) ? names.get(i) : "";
        }
    }

    public int currentIndex() { return index; }

    public void addTrack(Uri uri) {
        String name = uri.getLastPathSegment();
        try {
            String[] proj = {"_display_name"};
            try (android.database.Cursor c = appCtx.getContentResolver().query(uri, proj, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    String dn = c.getString(0);
                    if (dn != null && !dn.isEmpty()) name = dn;
                }
            }
        } catch (Exception ignored) { }
        tracks.add(uri);
        names.add(name == null ? "音频" : name);
        saveTracks();
        notifyState();
    }

    public void removeTrack(int i) {
        if (i < 0 || i >= tracks.size()) return;
        tracks.remove(i);
        names.remove(i);
        if (index >= tracks.size()) index = Math.max(0, tracks.size() - 1);
        saveTracks();
        notifyState();
        if (playing && tracks.isEmpty()) pause();
    }

    public void clearTracks() {
        tracks.clear();
        names.clear();
        index = 0;
        saveTracks();
        pause();
        notifyState();
    }

    public void selectTrack(int i) {
        if (i < 0 || i >= tracks.size()) return;
        index = i;
        restartDecoder();
        Listener l = listener;
        if (l != null) main.post(() -> l.onTrackChanged(index, trackName(index)));
        notifyState();
    }

    public void next() {
        if (tracks.isEmpty()) return;
        selectTrack((index + 1) % tracks.size());
    }

    public void prev() {
        if (tracks.isEmpty()) return;
        selectTrack((index - 1 + tracks.size()) % tracks.size());
    }

    // ---------------- 播放控制 ----------------

    public boolean isPlaying() { return playing; }
    public boolean isLoop() { return loop; }
    public void setLoop(boolean v) { loop = v; }
    public float volume() { return volume; }
    public void setVolume(float v) { volume = Math.max(0f, Math.min(2f, v)); }

    public boolean hasClient() { return client != null; }

    public void play() {
        if (tracks.isEmpty()) {
            error("没有音频，先添加文件");
            return;
        }
        if (playing) return;
        playing = true;
        restartDecoder();
        notifyState();
    }

    public void pause() {
        if (!playing) return;
        playing = false;
        queue.clear();
        notifyState();
    }

    public void toggle() {
        if (playing) pause(); else play();
    }

    private void error(String msg) {
        Listener l = listener;
        if (l != null) main.post(() -> l.onError(msg));
    }

    // ---------------- 服务生命周期 ----------------

    public void start() {
        if (running) return;
        running = true;
        acceptThread = new Thread(this::acceptLoop, "micmuse-accept");
        acceptThread.start();
        decodeThread = new Thread(this::decodeLoop, "micmuse-decode");
        decodeThread.start();
    }

    public void stop() {
        running = false;
        playing = false;
        dropClient();
        try {
            if (acceptThread != null) acceptThread.join(500);
            if (decodeThread != null) decodeThread.join(500);
        } catch (InterruptedException ignored) { }
        queue.clear();
    }

    // ---------------- 网络：只监听本机回环 ----------------

    private void acceptLoop() {
        ServerSocket ss = null;
        while (running) {
            try {
                if (ss == null) {
                    ss = new ServerSocket(Protocol.PORT, 4, InetAddress.getByName("127.0.0.1"));
                    Log.i(TAG, "listening on " + Protocol.PORT);
                }
                Socket s = ss.accept();
                s.setTcpNoDelay(true);
                handleClient(s);
            } catch (IOException e) {
                if (running) Log.w(TAG, "accept: " + e);
                closeQuietly(ss);
                ss = null;
                sleep(500);
            }
        }
        closeQuietly(ss);
    }

    private void handleClient(Socket s) {
        try {
            InputStream in = s.getInputStream();
            byte[] hdr = new byte[Protocol.REQ_LEN];
            int got = 0;
            while (got < hdr.length) {
                int n = in.read(hdr, got, hdr.length - got);
                if (n < 0) throw new IOException("eof in header");
                got += n;
            }
            for (int i = 0; i < 4; i++) {
                if (hdr[i] != Protocol.MAGIC_REQ[i]) throw new IOException("bad magic");
            }
            int sr = Protocol.getU32(hdr, 4);
            int ch = Protocol.getU16(hdr, 8);
            if (sr < 8000 || sr > 192000 || ch < 1 || ch > 2) throw new IOException("bad format");
            dstRate = sr;
            dstCh = ch;
            Log.i(TAG, "client attached: " + sr + "Hz/" + ch + "ch");

            dropClient();
            clientOut = s.getOutputStream();
            client = s;
            queue.clear();
            restartDecoder();
            notifyState();

            while (running && client == s) {
                byte[] pkt = queue.poll(200, TimeUnit.MILLISECONDS);
                if (pkt == null) {
                    // 空转时给一点静音，避免对方录音端读到陈旧数据产生杂音
                    pkt = new byte[packetBytes()];
                }
                ByteBuffer bb = ByteBuffer.allocate(4 + pkt.length);
                bb.putInt(pkt.length);
                bb.put(pkt);
                clientOut.write(bb.array());
                clientOut.flush();
            }
        } catch (Exception e) {
            Log.w(TAG, "client loop: " + e);
        } finally {
            closeQuietly(s);
            if (client == s) {
                dropClient();
                notifyState();
            }
        }
    }

    private int packetBytes() {
        int frames = Math.max(1, dstRate / (1000 / Protocol.PACKET_MS));
        return frames * dstCh * 2;
    }

    private void dropClient() {
        Socket s = client;
        client = null;
        clientOut = null;
        closeQuietly(s);
    }

    // ---------------- 解码线程 ----------------

    private volatile boolean decoderDirty = true;
    private volatile boolean fileEnded = false;

    private void restartDecoder() {
        decoderDirty = true;
    }

    private void decodeLoop() {
        Decoder dec = new Decoder();
        Resampler rs = null;
        int lastSrcRate = -1, lastSrcCh = -1, lastDstRate = -1, lastDstCh = -1;
        ByteBuffer carry = ByteBuffer.allocate(8192);
        carry.flip();

        while (running) {
            if (!playing || tracks.isEmpty()) {
                sleep(50);
                continue;
            }
            if (client == null) {
                sleep(80);          // 没人连：不推进播放
                continue;
            }

            int tr = index;
            try {
                if (decoderDirty) {
                    dec.close();
                    if (!dec.open(appCtx, safeGet(tr))) {
                        error("无法打开音频: " + trackName(tr));
                        playing = false;
                        notifyState();
                        sleep(200);
                        continue;
                    }
                    decoderDirty = false;
                    fileEnded = false;
                    rs = null;
                    carry.clear();
                    carry.flip();
                }

                byte[] chunk = dec.read();
                if (chunk == null) {
                    if (fileEnded) {
                        if (loop) { decoderDirty = true; continue; }
                        if (tr + 1 < tracks.size()) { selectTrack(tr + 1); continue; }
                        playing = false;
                        notifyState();
                        continue;
                    }
                    sleep(10);
                    continue;
                }
                fileEnded = dec.ended;

                short[] shorts = bytesToShorts(chunk);
                int frames = shorts.length / Math.max(1, dec.srcCh);

                if (rs == null || dec.srcRate != lastSrcRate || dec.srcCh != lastSrcCh
                        || dstRate != lastDstRate || dstCh != lastDstCh) {
                    rs = new Resampler(dec.srcRate, dec.srcCh, dstRate, dstCh);
                    lastSrcRate = dec.srcRate;
                    lastSrcCh = dec.srcCh;
                    lastDstRate = dstRate;
                    lastDstCh = dstCh;
                }
                byte[] out = rs.process(shorts, frames, volume);
                if (out.length == 0) continue;

                int pkt = packetBytes();
                ByteBuffer buf = ByteBuffer.allocate(carry.remaining() + out.length);
                buf.put(carry);
                buf.put(out);
                buf.flip();
                while (buf.remaining() >= pkt) {
                    byte[] p = new byte[pkt];
                    buf.get(p);
                    if (!queue.offer(p, 100, TimeUnit.MILLISECONDS)) {
                        // 队列满：客户端读得慢，丢最旧的包，保证低延迟
                        queue.poll();
                        queue.offer(p);
                    }
                }
                carry = ByteBuffer.allocate(Math.max(1024, buf.remaining()));
                carry.put(buf);
                carry.flip();
            } catch (Exception e) {
                Log.w(TAG, "decode: " + e);
                error("解码出错: " + e.getMessage());
                decoderDirty = true;
                sleep(300);
            }
        }
        dec.close();
    }

    private Uri safeGet(int i) {
        synchronized (tracks) {
            if (i >= 0 && i < tracks.size()) return tracks.get(i);
            return null;
        }
    }

    private static short[] bytesToShorts(byte[] b) {
        short[] s = new short[b.length / 2];
        for (int i = 0; i < s.length; i++) {
            s[i] = (short) ((b[i * 2] & 0xFF) | (b[i * 2 + 1] << 8));
        }
        return s;
    }

    // ---------------- 解码器封装 ----------------

    private static final class Decoder {
        MediaExtractor ex;
        MediaCodec codec;
        int srcRate = 48000, srcCh = 1;
        boolean ended;
        boolean inputDone;
        private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        private final ByteBuffer out = ByteBuffer.allocate(1 << 16);

        boolean open(Context ctx, Uri uri) {
            close();
            if (uri == null) return false;
            try {
                ex = new MediaExtractor();
                ex.setDataSource(ctx, uri, null);
                int track = -1;
                MediaFormat fmt = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat f = ex.getTrackFormat(i);
                    String mime = f.getString(MediaFormat.KEY_MIME);
                    if (mime != null && mime.startsWith("audio/")) {
                        track = i;
                        fmt = f;
                        break;
                    }
                }
                if (track < 0) return false;
                ex.selectTrack(track);
                srcRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 48000;
                srcCh = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
                String mime = fmt.getString(MediaFormat.KEY_MIME);
                codec = MediaCodec.createDecoderByType(mime);
                codec.configure(fmt, null, null, 0);
                codec.start();
                ended = false;
                inputDone = false;
                return true;
            } catch (Exception e) {
                Log.w(TAG, "Decoder.open: " + e);
                close();
                return false;
            }
        }

        /** 返回一段 s16le PCM；null 表示暂时没数据。文件结束时返回 null 且 ended=true。 */
        byte[] read() {
            if (codec == null) return null;
            try {
                int inIdx = codec.dequeueInputBuffer(0);
                if (inIdx >= 0) {
                    ByteBuffer ib = codec.getInputBuffer(inIdx);
                    int size = 0;
                    if (!inputDone && ex != null) {
                        size = ex.readSampleData(ib, 0);
                    }
                    if (size < 0) {
                        codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                    } else {
                        codec.queueInputBuffer(inIdx, 0, size, ex.getSampleTime(), 0);
                        ex.advance();
                    }
                }

                int outIdx = codec.dequeueOutputBuffer(info, 5000);
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat f = codec.getOutputFormat();
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) srcCh = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    return new byte[0];
                }
                if (outIdx < 0) return new byte[0];

                ByteBuffer ob = codec.getOutputBuffer(outIdx);
                byte[] res;
                if (ob != null && info.size > 0) {
                    ob.position(info.offset);
                    ob.limit(info.offset + info.size);
                    res = new byte[info.size];
                    ob.get(res);
                } else {
                    res = new byte[0];
                }
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                codec.releaseOutputBuffer(outIdx, false);
                if (eos) ended = true;
                return res;
            } catch (IllegalStateException e) {
                Log.w(TAG, "Decoder.read: " + e);
                ended = true;
                return null;
            }
        }

        void close() {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) { }
            codec = null;
            try { if (ex != null) ex.release(); } catch (Exception ignored) { }
            ex = null;
        }
    }

    // ---------------- 持久化 ----------------

    private void loadTracks() {
        SharedPreferences sp = appCtx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY_TRACKS, "");
        if (raw == null || raw.isEmpty()) return;
        for (String line : raw.split("\n")) {
            int t = line.indexOf('\t');
            if (t <= 0) continue;
            String name = line.substring(0, t);
            String uri = line.substring(t + 1);
            try {
                tracks.add(Uri.parse(uri));
                names.add(name);
            } catch (Exception ignored) { }
        }
    }

    private void saveTracks() {
        StringBuilder sb = new StringBuilder();
        synchronized (tracks) {
            for (int i = 0; i < tracks.size(); i++) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(names.get(i)).append('\t').append(tracks.get(i).toString());
            }
        }
        appCtx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(KEY_TRACKS, sb.toString()).apply();
    }

    // ---------------- 小工具 ----------------

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    private static void closeQuietly(java.io.Closeable c) {
        if (c == null) return;
        try { c.close(); } catch (IOException ignored) { }
    }
}
