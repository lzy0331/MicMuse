package com.dsh.micmuse;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** 前台服务：持有播放引擎 + 悬浮窗。 */
public final class OverlayService extends Service implements PlayerEngine.Listener {

    private static volatile OverlayService instance;

    public static OverlayService get() { return instance; }

    private PlayerEngine engine;
    private WindowManager wm;
    private View overlay;
    private WindowManager.LayoutParams lp;
    private TextView statusView;
    private Button playBtn;
    private LinearLayout trackBox;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refreshUi();
            ui.postDelayed(this, 700);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        engine = new PlayerEngine(this);
        engine.setListener(this);
        engine.start();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(1, buildNotification());
        showOverlay();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        if ("show".equals(act)) showOverlay();
        else if ("hide".equals(act)) hideOverlay();
        else if ("play".equals(act)) engine.play();
        else if ("pause".equals(act)) engine.pause();
        else showOverlay();
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        instance = null;
        ui.removeCallbacksAndMessages(null);
        hideOverlay();
        if (engine != null) engine.stop();
        super.onDestroy();
    }

    public PlayerEngine engine() { return engine; }

    // ---------------- 通知 ----------------

    private Notification buildNotification() {
        String ch = "micmuse";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(ch, "MicMuse", NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, ch)
                : new Notification.Builder(this);
        return b.setContentTitle("MicMuse 运行中")
                .setContentText("悬浮窗控制播放，注入模块在 127.0.0.1:" + Protocol.PORT + " 取流")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build();
    }

    // ---------------- 悬浮窗 ----------------

    private void showOverlay() {
        if (overlay != null) return;
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "没有悬浮窗权限，请到设置里授予", Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE6202124);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0x40FFFFFF);
        root.setBackground(bg);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("MicMuse");
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setPadding(dp(4), 0, 0, 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button close = new Button(this);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setMinWidth(0);
        close.setMinHeight(0);
        close.setOnClickListener(v -> hideOverlay());
        bar.addView(close);
        root.addView(bar);

        statusView = new TextView(this);
        statusView.setTextColor(0xFF9AD3FF);
        statusView.setTextSize(11);
        statusView.setPadding(dp(4), 0, 0, dp(4));
        root.addView(statusView);

        ScrollView sc = new ScrollView(this);
        sc.setLayoutParams(new LinearLayout.LayoutParams(dp(230), dp(120)));
        trackBox = new LinearLayout(this);
        trackBox.setOrientation(LinearLayout.VERTICAL);
        sc.addView(trackBox);
        root.addView(sc);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        playBtn = smallBtn("▶");
        playBtn.setOnClickListener(v -> {
            if (engine.isPlaying()) engine.pause(); else engine.play();
        });
        Button prev = smallBtn("⏮");
        prev.setOnClickListener(v -> engine.prev());
        Button next = smallBtn("⏭");
        next.setOnClickListener(v -> engine.next());
        row.addView(prev);
        row.addView(playBtn);
        row.addView(next);
        root.addView(row);

        SeekBar vol = new SeekBar(this);
        vol.setMax(200);
        vol.setProgress((int) (engine.volume() * 100));
        vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                engine.setVolume(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(vol);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(20);
        lp.y = dp(120);

        final float[] down = new float[2];
        final int[] start = new int[2];
        bar.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX();
                    down[1] = e.getRawY();
                    start[0] = lp.x;
                    start[1] = lp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = start[0] + (int) (e.getRawX() - down[0]);
                    lp.y = start[1] + (int) (e.getRawY() - down[1]);
                    if (overlay != null) wm.updateViewLayout(overlay, lp);
                    return true;
            }
            return false;
        });

        overlay = root;
        wm.addView(overlay, lp);
        rebuildTracks();
        ui.post(ticker);
    }

    private void hideOverlay() {
        ui.removeCallbacks(ticker);
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) { }
        }
        overlay = null;
    }

    public boolean isOverlayVisible() { return overlay != null; }

    private Button smallBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setMinWidth(dp(48));
        b.setMinHeight(dp(40));
        b.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1);
        p.setMargins(dp(2), dp(4), dp(2), dp(2));
        b.setLayoutParams(p);
        return b;
    }

    private void rebuildTracks() {
        if (trackBox == null) return;
        trackBox.removeAllViews();
        int n = engine.trackCount();
        for (int i = 0; i < n; i++) {
            TextView t = new TextView(this);
            String name = engine.trackName(i);
            t.setText((i == engine.currentIndex() ? "▶ " : "   ") + name);
            t.setTextColor(i == engine.currentIndex() ? 0xFF7CFFB2 : 0xFFE0E0E0);
            t.setTextSize(12);
            t.setPadding(dp(6), dp(6), dp(6), dp(6));
            t.setSingleLine(true);
            final int idx = i;
            t.setOnClickListener(v -> engine.selectTrack(idx));
            t.setOnLongClickListener(v -> {
                engine.removeTrack(idx);
                rebuildTracks();
                return true;
            });
            trackBox.addView(t);
        }
        if (n == 0) {
            TextView t = new TextView(this);
            t.setText("没歌，先在 App 里添加");
            t.setTextColor(0xFFAAAAAA);
            t.setTextSize(12);
            t.setPadding(dp(6), dp(6), dp(6), dp(6));
            trackBox.addView(t);
        }
    }

    private void refreshUi() {
        if (overlay == null) { ui.removeCallbacks(ticker); return; }
        if (playBtn != null) playBtn.setText(engine.isPlaying() ? "⏸" : "▶");
        if (statusView != null) {
            String s = engine.hasClient()
                    ? "已连上注入模块 · " + (engine.isPlaying() ? "播放中" : "待播放")
                    : "等待游戏/模块连接…";
            statusView.setText(s);
        }
        if (trackBox != null && trackBox.getChildCount() != Math.max(1, engine.trackCount())) {
            rebuildTracks();
        }
    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }

    // ---------------- PlayerEngine.Listener ----------------

    @Override public void onStateChanged() {
        ui.post(this::refreshUi);
    }

    @Override public void onTrackChanged(int index, String name) {
        ui.post(() -> {
            rebuildTracks();
            refreshUi();
        });
    }

    @Override public void onError(String msg) {
        ui.post(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }
}
