package com.dsh.micmuse;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** 主界面（全部用代码画，不依赖任何资源文件）。 */
public final class MainActivity extends Activity {

    private static final int REQ_PICK = 1001;
    private static final int REQ_OVERLAY = 1002;

    private LinearLayout listBox;
    private TextView status;
    private LinearLayout controls;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(buildUi());
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private View buildUi() {
        ScrollView sc = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(22));
        sc.addView(root);

        TextView title = new TextView(this);
        title.setText("MicMuse");
        title.setTextSize(24);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("把本地音频送进麦克风通路（需要安装 Zygisk 注入模块）");
        sub.setTextSize(12);
        sub.setAlpha(0.7f);
        root.addView(sub);

        status = new TextView(this);
        status.setTextSize(13);
        status.setPadding(0, dp(10), 0, dp(10));
        root.addView(status);

        Button pick = new Button(this);
        pick.setText("选择音频文件（可多选）");
        pick.setOnClickListener(v -> pickAudio());
        root.addView(pick);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(controls);

        SeekBar vol = new SeekBar(this);
        vol.setMax(200);
        vol.setPadding(0, dp(8), 0, dp(8));
        vol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (OverlayService.get() != null) OverlayService.get().engine().setVolume(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(vol);
        vol.setTag("volume");

        CheckBox loop = new CheckBox(this);
        loop.setText("循环播放");
        loop.setChecked(true);
        loop.setOnCheckedChangeListener((v, c) -> {
            if (OverlayService.get() != null) OverlayService.get().engine().setLoop(c);
        });
        root.addView(loop);

        Button overlay = new Button(this);
        overlay.setText("显示/隐藏悬浮窗");
        overlay.setOnClickListener(v -> toggleOverlay());
        root.addView(overlay);

        Button clear = new Button(this);
        clear.setText("清空列表");
        clear.setOnClickListener(v -> {
            if (OverlayService.get() != null) {
                OverlayService.get().engine().clearTracks();
            } else {
                getSharedPreferences("micmuse", MODE_PRIVATE).edit().remove("tracks").apply();
            }
            refresh();
        });
        root.addView(clear);

        TextView tip = new TextView(this);
        tip.setText("\n用法：\n1. 添加音频\n2. 点「显示/隐藏悬浮窗」，进游戏后从悬浮窗选歌播放\n"
                + "3. 游戏里语音输入才有效（模块只接管录音端）\n"
                + "4. 只有注入模块连上时才推进播放，没连上不会白播");
        tip.setTextSize(11);
        tip.setAlpha(0.75f);
        root.addView(tip);

        return sc;
    }

    // ---------------- 交互 ----------------

    private void pickAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Exception e) {
            Toast.makeText(this, "没有找到文件选择器", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) { refresh(); return; }
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;

        ensureService();
        PlayerEngine engine = OverlayService.get() == null ? null : OverlayService.get().engine();
        if (engine == null) { Toast.makeText(this, "服务没起来", Toast.LENGTH_SHORT).show(); return; }

        int added = 0;
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri u = data.getClipData().getItemAt(i).getUri();
                takePerm(u);
                engine.addTrack(u);
                added++;
            }
        } else if (data.getData() != null) {
            takePerm(data.getData());
            engine.addTrack(data.getData());
            added++;
        }
        Toast.makeText(this, "已添加 " + added + " 个文件", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void takePerm(Uri u) {
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
    }

    private void toggleOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
            return;
        }
        OverlayService svc = OverlayService.get();
        if (svc == null) {
            ensureService();
        } else {
            Intent i = new Intent(this, OverlayService.class);
            i.setAction(svc.isOverlayVisible() ? "hide" : "show");
            startService(i);
        }
        refresh();
    }

    private void ensureService() {
        if (OverlayService.get() != null) return;
        Intent i = new Intent(this, OverlayService.class);
        i.setAction("show");
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    // ---------------- 界面刷新 ----------------

    private void refresh() {
        OverlayService svc = OverlayService.get();
        PlayerEngine engine = svc == null ? null : svc.engine();
        boolean running = engine != null;

        if (status != null) {
            if (!running) {
                status.setText("服务未启动（点下面的按钮或选歌会自动启动）");
            } else {
                String s = "服务运行中 · 端口 " + Protocol.PORT + " · "
                        + (engine.hasClient() ? "模块已连接" : "等待模块连接");
                status.setText(s);
            }
        }

        if (listBox != null) {
            listBox.removeAllViews();
            int n = running ? engine.trackCount() : 0;
            for (int i = 0; i < n; i++) {
                final int idx = i;
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                TextView name = new TextView(this);
                name.setText((i == engine.currentIndex() ? "▶ " : "· ") + engine.trackName(i));
                name.setTextSize(13);
                name.setSingleLine(true);
                name.setPadding(0, dp(8), 0, dp(8));
                name.setOnClickListener(v -> {
                    engine.selectTrack(idx);
                    refresh();
                });
                row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                Button del = new Button(this);
                del.setText("移除");
                del.setOnClickListener(v -> {
                    engine.removeTrack(idx);
                    refresh();
                });
                row.addView(del);
                listBox.addView(row);
            }
            if (n == 0) {
                TextView empty = new TextView(this);
                empty.setText("列表为空");
                empty.setAlpha(0.6f);
                listBox.addView(empty);
            }
        }

        if (controls != null) {
            controls.removeAllViews();
            Button prev = new Button(this);
            prev.setText("上一首");
            prev.setOnClickListener(v -> { if (engine != null) { engine.prev(); refresh(); } });
            Button play = new Button(this);
            play.setText(running && engine.isPlaying() ? "暂停" : "播放");
            play.setOnClickListener(v -> {
                ensureService();
                if (OverlayService.get() != null) {
                    OverlayService.get().engine().toggle();
                }
                refresh();
            });
            Button next = new Button(this);
            next.setText("下一首");
            next.setOnClickListener(v -> { if (engine != null) { engine.next(); refresh(); } });
            controls.addView(prev, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            controls.addView(play, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            controls.addView(next, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        }

    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }
}
