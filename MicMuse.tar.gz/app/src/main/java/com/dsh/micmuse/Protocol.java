package com.dsh.micmuse;

/** 与 Zygisk 注入模块之间的线协议常量与工具方法。 */
public final class Protocol {
    /** 本机回环端口，注入模块连这里取 PCM。 */
    public static final int PORT = 35791;

    /** 客户端(注入模块) -> App 的请求头: "MMRQ" + u32 rate + u16 channels + u16 bits */
    public static final byte[] MAGIC_REQ = {'M', 'M', 'R', 'Q'};
    public static final int REQ_LEN = 12;

    /** App -> 客户端 的数据包: u32 len + PCM(s16le, 交错) */
    public static final int PACKET_MS = 20;

    public static byte[] buildRequestHeader(int sampleRate, int channels, int bits) {
        byte[] b = new byte[REQ_LEN];
        System.arraycopy(MAGIC_REQ, 0, b, 0, 4);
        putU32(b, 4, sampleRate);
        putU16(b, 8, channels);
        putU16(b, 10, bits);
        return b;
    }

    public static int getU16(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8);
    }

    public static int getU32(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8)
                | ((b[off + 2] & 0xFF) << 16) | ((b[off + 3] & 0xFF) << 24);
    }

    public static void putU16(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >>> 8) & 0xFF);
    }

    public static void putU32(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >>> 8) & 0xFF);
        b[off + 2] = (byte) ((v >>> 16) & 0xFF);
        b[off + 3] = (byte) ((v >>> 24) & 0xFF);
    }

    private Protocol() {}
}
