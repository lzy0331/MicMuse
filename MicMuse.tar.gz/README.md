# MicMuse

把本机音频"注进"麦克风通路的工具：一个悬浮窗播放器 App + 一个 Zygisk 注入模块。

- **App**（`app/`，Java，零第三方依赖）：选择本地音频、列表管理、播放/暂停/切歌、音量、循环；悬浮窗常驻可拖动。用 MediaCodec 解码，重采样到录音端要求的采样率/声道，通过 `127.0.0.1:35791` 推流。
- **模块**（`module/`，C++）：Zygisk 模块。命中 `targets.conf` 里的包名后，在目标进程里等 `AudioRecord::read` 符号出现，用内联 hook 接管读取：有数据就用 App 的 PCM，没有就原样走真麦克风。

## 原理一句话

游戏语音（含走 OpenSL ES / AAudio 的）最终都落到 libaudioclient 的 `android::AudioRecord::read`。把它换成"从我们的环形缓冲取数据"，队友听到的就是你放的音乐。

## 构建

### 1) App（AndroidIDE 或任意 Android Studio）

AndroidIDE：打开本目录 → 等待同步 → Build → APK 输出在 `app/build/outputs/apk/debug/app-debug.apk`。

命令行：

```bash
gradle :app:assembleDebug
```

### 2) Zygisk 模块（必须是 arm64、需要 NDK）

需要：Android NDK（r26/r27 皆可）、cmake、ZygiskNDK 头文件。

```bash
git clone --depth 1 https://github.com/Dr-TSNG/ZygiskNDK
NDK=/path/to/android-ndk ZYGISK_NDK=$PWD/ZygiskNDK sh module/build.sh
```

产物：`module/build/out/`（可直接作为模块目录）。

> 手机上装 NDK 比较重（约 1GB）。如果嫌麻烦，直接推仓库到 GitHub，`.github/workflows/build.yml` 会同时产出 **APK** 和 **模块 zip** 两个 artifact。

## 安装

1. 装 APK。
2. 装 ZygiskNext（KernelSU 环境需要它才有 Zygisk）：从其 GitHub Release 下载 zip，用 KernelSU 的"安装模块"装，重启。
3. 部署本模块：把 `module/build/out/` 里的内容放到 `/data/adb/modules/micmuse/`
   ```bash
   su -c 'mkdir -p /data/adb/modules/micmuse && cp -r /sdcard/Download/micmuse-module/* /data/adb/modules/micmuse/ && chmod -R 755 /data/adb/modules/micmuse'
   ```
4. 编辑 `/data/adb/modules/micmuse/targets.conf`，写入要注入的包名（默认 `com.tencent.tmgp.sgame`）。
5. 重启手机（或至少完全退出目标游戏）。

## 使用

1. 打开 MicMuse，授予悬浮窗权限，添加音频。
2. 进游戏，开始语音（组队语音/开麦）。悬浮窗状态会从"等待模块连接…"变成"已连上注入模块"。
3. 悬浮窗里选歌、点播放。**没连上模块时不会推进播放**，不会白播。

## 排查

```bash
# 模块日志
adb logcat -s MicMuse
```

常见输出：
- `目标进程命中: com.tencent.tmgp.sgame` —— 注入配置生效
- `找到符号 ... read` + `注入就绪` —— hook 成功
- `90s 内没等到 AudioRecord::read` —— 游戏还没开语音，或该进程不做录音
- `目标函数首条指令是 PC 相对/分支` —— 机型/版本差异，hook 主动放弃（麦克风保持正常）

App 侧：`adb logcat -s MicMuse/Engine`。

## 风险与回退

- 游戏可能因 Zygisk/root 被反作弊判定。**建议先用小号试**。
- 回退：删除 `/data/adb/modules/micmuse` 后重启，麦克风立即恢复原状；App 卸载即可。
- 本方案不改系统分区、不写代码段以外的任何东西；hook 失败自动回退到真麦克风。

## 调参：format.conf

模块默认从 `AudioRecord` 自身读采样率/声道；如果读不到（符号被隐藏），默认按 48000Hz / 单声道处理。
出现"音调不对/变快变慢"时，在模块目录放一个 `format.conf`：

```
# 采样率, 声道数
16000,1
```

改完重启游戏进程即可生效（模块只在进程启动时读一次）。
