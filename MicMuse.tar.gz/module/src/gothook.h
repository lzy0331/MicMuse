#pragma once
#include <cstddef>

/**
 * GOT 重定向：扫描所有已加载库的 .rela.plt，把引用指定符号的槽位改成 repl。
 * 只改可写数据页（mprotect 到 RW），不需要可执行映射，SELinux 下成功率高于内联 hook。
 *
 * @param symPrefix 符号名前缀（C++ mangled），如 "_ZN7android11AudioRecord4read"
 * @param repl      替换函数地址
 * @param origOut   输出：第一个槽位的原值（可能是真实函数，也可能是 PLT resolver stub）
 * @return 被打补丁的槽位数量
 */
int hookGotPrefix(const char* symPrefix, void* repl, void** origOut);

/** 惰性绑定会把槽位改回真实地址，这里在每次回退调用后重新写回我们的函数。 */
void rearmGotHooks();

/** 已记录的槽位数量。 */
int gotHookCount();
