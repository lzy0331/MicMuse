#include "hook.h"

#include <android/log.h>
#include <sys/mman.h>
#include <unistd.h>
#include <cstring>
#include <cstdint>

#ifndef MAP_FIXED_NOREPLACE
#define MAP_FIXED_NOREPLACE 0x100000
#endif

#define TAG "MicMuse"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

// 这些编码放到 trampoline 里会算错地址或跳飞，遇到就放弃挂钩
bool isPcRelativeOrBranch(uint32_t insn) {
    if ((insn & 0x7C000000u) == 0x14000000u) return true; // B / BL
    if ((insn & 0x1F000000u) == 0x10000000u) return true; // ADR / ADRP
    if ((insn & 0x3B000000u) == 0x18000000u) return true; // LDR (literal)
    if ((insn & 0xFF000010u) == 0x54000000u) return true; // B.cond
    if ((insn & 0x7E000000u) == 0x34000000u) return true; // CBZ / CBNZ
    if ((insn & 0x7E000000u) == 0x36000000u) return true; // TBZ / TBNZ
    return false;
}

void* mapGateNear(void* target) {
    const uintptr_t page = 4096, step = 0x100000; // 1MB 步进
    uintptr_t t = (uintptr_t) target;
    for (int i = 1; i <= 96; i++) {
        for (int dir = -1; dir <= 1; dir += 2) {
            uintptr_t hint = t + (dir > 0 ? (uintptr_t) i : (uintptr_t) (-(int64_t) i)) * step;
            hint &= ~(page - 1);
            void* p = mmap(reinterpret_cast<void*>(hint), page,
                           PROT_READ | PROT_WRITE | PROT_EXEC,
                           MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
            if (p == reinterpret_cast<void*>(hint)) return p;
            if (p != MAP_FAILED) munmap(p, page);
        }
    }
    return nullptr;
}

bool mprotectAll(void* addr, size_t len, int prot) {
    uintptr_t start = reinterpret_cast<uintptr_t>(addr) & ~(uintptr_t) 4095;
    size_t total = (reinterpret_cast<uintptr_t>(addr) + len) - start;
    return mprotect(reinterpret_cast<void*>(start), total, prot) == 0;
}

} // namespace

bool installInlineHook(void* target, void* replacement, void** orig) {
    if (!target || !replacement) return false;

    uint32_t saved = *reinterpret_cast<uint32_t*>(target);
    if (isPcRelativeOrBranch(saved)) {
        LOGE("目标函数首条指令是 PC 相对/分支(0x%08x)，放弃挂钩", saved);
        return false;
    }

    void* gate = mapGateNear(target);
    if (!gate) {
        LOGE("找不到目标函数附近的空页，放弃挂钩");
        return false;
    }

    uint32_t* g = static_cast<uint32_t*>(gate);
    // [0] ldr x16,#8  [1] br x16  [2..3] replacement
    g[0] = 0x58000050u;
    g[1] = 0xD61F0200u;
    { void* p = replacement; memcpy(&g[2], &p, 8); }
    // [4] 原首条指令  [5] ldr x16,#8(PC=+8 → g[7])  [6] br x16  [7..8] target+4
    g[4] = saved;
    g[5] = 0x58000050u;
    g[6] = 0xD61F0200u;
    { void* p = reinterpret_cast<char*>(target) + 4; memcpy(&g[7], &p, 8); }

    __builtin___clear_cache(reinterpret_cast<char*>(gate), reinterpret_cast<char*>(gate) + 64);

    int64_t off = reinterpret_cast<int64_t>(gate) - reinterpret_cast<int64_t>(target);
    if (off % 4 != 0 || off < -(1LL << 27) || off >= (1LL << 27)) {
        LOGE("跳转距离超范围: %lld", (long long) off);
        munmap(gate, 4096);
        return false;
    }

    if (!mprotectAll(target, 4, PROT_READ | PROT_WRITE | PROT_EXEC)) {
        LOGE("mprotect 代码页失败");
        munmap(gate, 4096);
        return false;
    }

    uint32_t b = 0x14000000u | ((uint32_t) ((off >> 2) & 0x03FFFFFFu));
    memcpy(target, &b, 4);
    __builtin___clear_cache(reinterpret_cast<char*>(target), reinterpret_cast<char*>(target) + 4);

    // 尽量恢复只读可执行（失败也不致命）
    mprotectAll(target, 4, PROT_READ | PROT_EXEC);

    *orig = reinterpret_cast<void*>(&g[4]);
    LOGI("已挂钩 %p -> gate %p", target, gate);
    return true;
}
