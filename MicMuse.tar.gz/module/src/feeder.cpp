#include "feeder.h"

#include <android/log.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <algorithm>
#include <cstring>
#include <thread>

#define TAG "MicMuse"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

namespace feeder {

namespace {
constexpr int kPort = 35791;
constexpr size_t kRing = 1u << 20;      // 1MB，48k 单声道约 10s 余量
constexpr int kRetryMs = 1000;

uint8_t g_ring[kRing];
std::atomic<uint64_t> g_w{0}, g_r{0};
std::atomic<bool> g_conn{false};
std::atomic<bool> g_running{false};
std::atomic<int> g_rate{48000};
std::atomic<int> g_ch{1};
std::thread g_thread;

bool readFull(int fd, void* buf, size_t n) {
    auto* p = static_cast<uint8_t*>(buf);
    while (n > 0) {
        ssize_t r = ::recv(fd, p, n, 0);
        if (r <= 0) return false;
        p += r;
        n -= (size_t) r;
    }
    return true;
}

void push(const uint8_t* data, size_t n) {
    if (n == 0) return;
    if (n > kRing) {                 // 超长包只保留尾部
        data += (n - kRing);
        n = kRing;
    }
    uint64_t w = g_w.load(std::memory_order_relaxed);
    uint64_t r = g_r.load(std::memory_order_relaxed);
    if (w - r + n > kRing) {         // 满了丢最旧的
        g_r.store(w + n - kRing, std::memory_order_relaxed);
    }
    size_t off = (size_t) (w % kRing);
    size_t first = std::min(n, kRing - off);
    memcpy(g_ring + off, data, first);
    if (n > first) memcpy(g_ring, data + first, n - first);
    g_w.store(w + n, std::memory_order_release);
}

void loop() {
    LOGI("feeder 线程启动");
    while (g_running.load()) {
        int fd = ::socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, 0);
        if (fd < 0) { usleep(kRetryMs * 1000); continue; }

        sockaddr_in a{};
        a.sin_family = AF_INET;
        a.sin_port = htons(kPort);
        a.sin_addr.s_addr = inet_addr("127.0.0.1");

        if (::connect(fd, reinterpret_cast<sockaddr*>(&a), sizeof(a)) == 0) {
            int one = 1;
            setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
            int rcv = 1 << 20;
            setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcv, sizeof(rcv));

            uint8_t hdr[12] = {'M', 'M', 'R', 'Q', 0, 0, 0, 0, 0, 0, 0, 0};
            uint32_t sr = (uint32_t) g_rate.load();
            uint16_t ch = (uint16_t) g_ch.load();
            hdr[4] = sr & 0xFF; hdr[5] = (sr >> 8) & 0xFF;
            hdr[6] = (sr >> 16) & 0xFF; hdr[7] = (sr >> 24) & 0xFF;
            hdr[8] = ch & 0xFF; hdr[9] = (ch >> 8) & 0xFF;
            hdr[10] = 16; hdr[11] = 0;

            if (::send(fd, hdr, sizeof(hdr), MSG_NOSIGNAL) == (ssize_t) sizeof(hdr)) {
                g_conn.store(true);
                LOGI("已连上 App: %u Hz / %u ch", sr, (unsigned) ch);
                g_r.store(g_w.load());
                uint8_t buf[16384];
                while (g_running.load()) {
                    uint8_t lenb[4];
                    if (!readFull(fd, lenb, 4)) break;
                    uint32_t len = (uint32_t) lenb[0] | ((uint32_t) lenb[1] << 8)
                                   | ((uint32_t) lenb[2] << 16) | ((uint32_t) lenb[3] << 24);
                    if (len == 0 || len > sizeof(buf)) break;
                    if (!readFull(fd, buf, len)) break;
                    push(buf, len);
                }
                g_conn.store(false);
                LOGW("与 App 的连接断开，准备重连");
            }
            ::close(fd);
        } else {
            ::close(fd);
        }
        usleep(kRetryMs * 1000);
    }
    LOGI("feeder 线程退出");
}

} // namespace

void setFormat(int sampleRate, int channels) {
    g_rate.store(sampleRate > 0 ? sampleRate : 48000);
    g_ch.store(channels > 0 ? channels : 1);
}

void start() {
    bool expected = false;
    if (!g_running.compare_exchange_strong(expected, true)) return;
    g_thread = std::thread(loop);
    g_thread.detach();
}

void stop() { g_running.store(false); }

bool connected() { return g_conn.load(std::memory_order_acquire); }

size_t read(uint8_t* dst, size_t n) {
    if (!g_conn.load(std::memory_order_acquire) || n == 0) return 0;
    uint64_t w = g_w.load(std::memory_order_acquire);
    uint64_t r = g_r.load(std::memory_order_relaxed);
    uint64_t avail = w - r;
    if (avail == 0) return 0;
    size_t take = (size_t) std::min<uint64_t>(avail, n);
    size_t off = (size_t) (r % kRing);
    size_t first = std::min(take, kRing - off);
    memcpy(dst, g_ring + off, first);
    if (take > first) memcpy(dst + first, g_ring, take - first);
    g_r.store(r + take, std::memory_order_release);
    return take;
}

}
