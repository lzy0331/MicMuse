#include <jni.h>
#include <dlfcn.h>
#include <unistd.h>
#include <android/log.h>

#include <atomic>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <mutex>
#include <string>
#include <thread>

#include "zygisk.hpp"
#include "feeder.h"
#include "hook.h"
#include "gothook.h"

#define TAG "MicMuse"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

using ReadFn = ssize_t (*)(void*, void*, size_t, bool);
using U32Fn = uint32_t (*)(void*);

ReadFn g_origRead = nullptr;
bool g_useGot = false;
U32Fn g_getSampleRate = nullptr;
U32Fn g_getChannelCount = nullptr;
std::once_flag g_fmtOnce;

void loadFormatOverride(const char* dir) {
    std::ifstream in(std::string(dir) + "/format.conf");
    if (!in) return;
    std::string line;
    while (std::getline(in, line)) {
        auto b = line.find_first_not_of(" \t\r\n,");
        if (b == std::string::npos || line[b] == "#") continue;
        int sr = 0, ch = 0;
        if (sscanf(line.c_str() + b, "%d%*[ ,]%d", &sr, &ch) == 2 && sr >= 8000 && ch >= 1 && ch <= 2) {
            feeder::setFormat(sr, ch);
            LOGI("使用 format.conf 覆盖格式: %d Hz / %d ch", sr, ch);
            std::call_once(g_fmtOnce, []{});
            feeder::start();
            return;
        }
    }
}

ssize_t hookRead(void* thiz, void* buf, size_t size, bool blocking) {
    std::call_once(g_fmtOnce, [thiz] {
        int sr = g_getSampleRate ? (int) g_getSampleRate(thiz) : 48000;
        int ch = g_getChannelCount ? (int) g_getChannelCount(thiz) : 1;
        feeder::setFormat(sr, ch);
        feeder::start();
        LOGI("录音格式: %d Hz / %d ch", sr, ch);
    });

    if (!g_origRead) return 0;
    if (!feeder::connected()) {
        ssize_t r = g_origRead(thiz, buf, size, blocking);
        if (g_useGot) rearmGotHooks();   // 惰性绑定可能把槽位改回去
        return r;
    }

    size_t got = feeder::read(static_cast<uint8_t*>(buf), size);
    if (got < size) memset(static_cast<uint8_t*>(buf) + got, 0, size - got);
    return (ssize_t) size;
}

bool isTarget(const std::string& confPath, const std::string& pkg) {
    std::ifstream in(confPath);
    if (!in) {
        LOGE("读不到 %s", confPath.c_str());
        return false;
    }
    std::string line;
    while (std::getline(in, line)) {
        auto b = line.find_first_not_of(" \t\r\n");
        if (b == std::string::npos) continue;
        if (line[b] == '#') continue;
        auto e = line.find_last_not_of(" \t\r\n");
        std::string item = line.substr(b, e - b + 1);
        if (item == pkg) return true;
    }
    return false;
}

void watchAndHook() {
    static const char* kReadSyms[] = {
            "_ZN7android11AudioRecord4readEPvmb",   // read(void*, size_t, bool)
            "_ZN7android11AudioRecord4readEPvm",    // read(void*, size_t)
    };
    for (int i = 0; i < 900; i++) {                 // 最多等 90s
        // 1) 先试 GOT 重定向：只改数据页，SELinux 下最稳
        void* orig = nullptr;
        int got = hookGotPrefix("_ZN7android11AudioRecord4read",
                                reinterpret_cast<void*>(hookRead), &orig);
        if (got > 0) {
            g_useGot = true;
            g_origRead = reinterpret_cast<ReadFn>(orig);
            g_getSampleRate = reinterpret_cast<U32Fn>(dlsym(RTLD_DEFAULT, "_ZNK7android11AudioRecord13getSampleRateEv"));
            g_getChannelCount = reinterpret_cast<U32Fn>(dlsym(RTLD_DEFAULT, "_ZNK7android11AudioRecord15getChannelCountEv"));
            LOGI("GOT 重定向完成：%d 个槽位，注入就绪", got);
            return;
        }
        // 2) 再试内联 hook（需要符号地址）
        void* fn = nullptr;
        for (const char* sym : kReadSyms) {
            fn = dlsym(RTLD_DEFAULT, sym);
            if (fn) { LOGI("找到符号 %s @ %p", sym, fn); break; }
        }
        if (fn) {
            g_getSampleRate = reinterpret_cast<U32Fn>(dlsym(RTLD_DEFAULT, "_ZNK7android11AudioRecord13getSampleRateEv"));
            g_getChannelCount = reinterpret_cast<U32Fn>(dlsym(RTLD_DEFAULT, "_ZNK7android11AudioRecord15getChannelCountEv"));
            if (installInlineHook(fn, reinterpret_cast<void*>(hookRead), &orig)) {
                g_origRead = reinterpret_cast<ReadFn>(orig);
                LOGI("内联 hook 注入就绪");
            } else {
                LOGE("挂钩失败，保持原麦克风");
            }
            return;
        }
        usleep(100 * 1000);
    }
    LOGE("90s 内没等到 AudioRecord::read，放弃注入");
}

} // namespace

class MicMuseModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api* api, JNIEnv* env) override {
        api_ = api;
        env_ = env;
    }

    void preAppSpecialize(zygisk::AppSpecializeArgs* args) override {
        // 目标判断放到 post 里做（那时才能拿到模块目录读 targets.conf）
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs* args) override {
        if (!env_ || !api_ || !args) return;
        const char* raw = env_->GetStringUTFChars(args->nice_name, nullptr);
        if (!raw) return;
        std::string proc(raw);
        env_->ReleaseStringUTFChars(args->nice_name, raw);

        std::string pkg = proc;
        auto colon = pkg.find(':');
        if (colon != std::string::npos) pkg = pkg.substr(0, colon);

        std::string dir;
        try {
            dir = api_->getModuleDir();
        } catch (...) {
            return;
        }
        if (dir.empty()) return;

        if (!isTarget(dir + "/targets.conf", pkg)) return;
        LOGI("目标进程命中: %s", proc.c_str());
        loadFormatOverride(dir.c_str());
        std::thread(watchAndHook).detach();
    }

private:
    zygisk::Api* api_ = nullptr;
    JNIEnv* env_ = nullptr;
};

REGISTER_ZYGISK_MODULE(MicMuseModule)
