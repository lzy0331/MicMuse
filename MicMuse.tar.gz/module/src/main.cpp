#include <jni.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <unistd.h>
#include <android/log.h>

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>
#include <mutex>
#include <vector>

#include "zygisk.hpp"
#include "feeder.h"
#include "hook.h"
#include "gothook.h"

#define TAG "MicMuse"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

using ReadFn = ssize_t (*)(void*, void*, size_t, bool);
using U32Fn = uint32_t (*)(void*);

ReadFn g_origRead = nullptr;
bool g_useGot = false;
U32Fn g_getSampleRate = nullptr;
U32Fn g_getChannelCount = nullptr;
std::once_flag g_fmtOnce;

// preAppSpecialize 阶段读到的配置（post 阶段没有权限再读 /data/adb）
bool g_isTarget = false;
bool g_hasFmtOverride = false;
int g_ovRate = 0;
int g_ovCh = 0;

std::string trim(const std::string& s) {
    auto b = s.find_first_not_of(" \t\r\n,");
    if (b == std::string::npos) return "";
    auto e = s.find_last_not_of(" \t\r\n,");
    return s.substr(b, e - b + 1);
}

std::vector<std::string> readLines(int dirFd, const char* name) {
    std::vector<std::string> out;
    int fd = openat(dirFd, name, O_RDONLY);
    if (fd < 0) {
        LOGW("打不开 %s (fd=%d)", name, fd);
        return out;
    }
    std::string all;
    char buf[2048];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) > 0) all.append(buf, (size_t) n);
    close(fd);
    size_t pos = 0;
    while (pos <= all.size()) {
        size_t nl = all.find('\n', pos);
        if (nl == std::string::npos) nl = all.size();
        std::string line = trim(all.substr(pos, nl - pos));
        if (!line.empty() && line[0] != '#') out.push_back(line);
        if (nl == all.size()) break;
        pos = nl + 1;
    }
    return out;
}

bool configHasPackage(int dirFd, const std::string& pkg) {
    for (const auto& line : readLines(dirFd, "targets.conf")) {
        if (line == pkg) return true;
    }
    return false;
}

void readFormatOverride(int dirFd) {
    for (const auto& line : readLines(dirFd, "format.conf")) {
        int sr = 0, ch = 0;
        if (sscanf(line.c_str(), "%d%*[ ,]%d", &sr, &ch) == 2 && sr >= 8000 && ch >= 1 && ch <= 2) {
            g_ovRate = sr;
            g_ovCh = ch;
            g_hasFmtOverride = true;
            LOGI("format.conf: %d Hz / %d ch", sr, ch);
            return;
        }
    }
}

ssize_t hookRead(void* thiz, void* buf, size_t size, bool blocking) {
    std::call_once(g_fmtOnce, [thiz] {
        int sr = g_hasFmtOverride ? g_ovRate : (g_getSampleRate ? (int) g_getSampleRate(thiz) : 48000);
        int ch = g_hasFmtOverride ? g_ovCh : (g_getChannelCount ? (int) g_getChannelCount(thiz) : 1);
        feeder::setFormat(sr, ch);
        feeder::start();
        LOGI("录音格式: %d Hz / %d ch", sr, ch);
    });

    if (!g_origRead) return 0;
    if (!feeder::connected()) {
        ssize_t r = g_origRead(thiz, buf, size, blocking);
        if (g_useGot) rearmGotHooks();
        return r;
    }
    size_t got = feeder::read(static_cast<uint8_t*>(buf), size);
    if (got < size) memset(static_cast<uint8_t*>(buf) + got, 0, size - got);
    return (ssize_t) size;
}

void watchAndHook() {
    static const char* kReadSyms[] = {
            "_ZN7android11AudioRecord4readEPvmb",
            "_ZN7android11AudioRecord4readEPvm",
    };
    for (int i = 0; i < 900; i++) {                 // 最多等 90 秒
        void* orig = nullptr;
        int got = hookGotPrefix("_ZN7android11AudioRecord4read",
                                reinterpret_cast<void*>(hookRead), &orig);
        if (got > 0) {
            g_useGot = true;
            g_origRead = reinterpret_cast<ReadFn>(orig);
            LOGI("GOT 重定向完成：%d 个槽位", got);
            return;
        }
        void* fn = nullptr;
        for (const char* sym : kReadSyms) {
            fn = dlsym(RTLD_DEFAULT, sym);
            if (fn) { LOGI("找到符号 %s", sym); break; }
        }
        if (fn) {
            g_getSampleRate = reinterpret_cast<U32Fn>(
                    dlsym(RTLD_DEFAULT, "_ZNK7android11AudioRecord13getSampleRateEv"));
            g_getChannelCount = reinterpret_cast<U32Fn>(
                    dlsym(RTLD_DEFAULT, "_ZNK7android11AudioRecord15getChannelCountEv"));
            if (installInlineHook(fn, reinterpret_cast<void*>(hookRead), &orig)) {
                g_origRead = reinterpret_cast<ReadFn>(orig);
                LOGI("内联 hook 注入就绪");
            } else {
                LOGE("挂钩失败，保持原麦克风");
            }
            return;
        }
        usleep(100 * 1000);
    }
    LOGE("90s 内没等到 AudioRecord::read，放弃注入");
}

} // namespace

class MicMuseModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api* api, JNIEnv* env) override {
        api_ = api;
        env_ = env;
    }

    // 只有在 pre 阶段才能拿模块目录、读 /data/adb 里的配置
    void preAppSpecialize(zygisk::AppSpecializeArgs* args) override {
        if (!env_ || !args) return;
        const char* raw = env_->GetStringUTFChars(args->nice_name, nullptr);
        if (!raw) return;
        std::string proc(raw);
        env_->ReleaseStringUTFChars(args->nice_name, raw);

        std::string pkg = proc;
        auto colon = pkg.find(':');
        if (colon != std::string::npos) pkg = pkg.substr(0, colon);

        int dirFd = api_ ? api_->getModuleDir() : -1;
        if (dirFd < 0) {
            LOGW("拿不到模块目录 fd，跳过 (%s)", pkg.c_str());
            return;
        }
        if (!configHasPackage(dirFd, pkg)) return;

        g_isTarget = true;
        readFormatOverride(dirFd);
        close(dirFd);
        LOGI("目标进程命中: %s", proc.c_str());
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs* args) override {
        if (!g_isTarget) return;          // 非目标进程：什么都不做
        std::thread(watchAndHook).detach();
    }

private:
    zygisk::Api* api_ = nullptr;
    JNIEnv* env_ = nullptr;
};

REGISTER_ZYGISK_MODULE(MicMuseModule)
