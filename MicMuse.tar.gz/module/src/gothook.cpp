#include "gothook.h"

#include <android/log.h>
#include <elf.h>
#include <link.h>
#include <sys/mman.h>
#include <cstring>
#include <vector>

#define TAG "MicMuse"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

namespace {

struct Slot {
    void** addr;
    void* repl;
};

std::vector<Slot> g_slots;
const char* g_prefix = nullptr;
size_t g_prefixLen = 0;
void* g_orig = nullptr;

void* resolvePtr(uintptr_t base, uint64_t v) {
    return reinterpret_cast<void*>(v < base ? base + v : v);
}

bool patchSlot(void** slot, void* value) {
    auto page = reinterpret_cast<uintptr_t>(slot) & ~(uintptr_t) 4095;
    if (mprotect(reinterpret_cast<void*>(page), 4096, PROT_READ | PROT_WRITE) != 0) {
        LOGW("mprotect GOT 页失败: %p", slot);
        return false;
    }
    *slot = value;
    mprotect(reinterpret_cast<void*>(page), 4096, PROT_READ);
    return true;
}

int callback(struct dl_phdr_info* info, size_t, void*) {
    if (!g_prefix) return 0;

    ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++) {
        const ElfW(Phdr)& ph = info->dlpi_phdr[i];
        if (ph.p_type == PT_DYNAMIC) {
            dyn = reinterpret_cast<ElfW(Dyn)*>(info->dlpi_addr + ph.p_vaddr);
            break;
        }
    }
    if (!dyn) return 0;

    uintptr_t base = info->dlpi_addr;
    ElfW(Sym)* symtab = nullptr;
    const char* strtab = nullptr;
    ElfW(Rela)* jmprel = nullptr;
    size_t jmprelsz = 0;
    size_t relaent = sizeof(ElfW(Rela));

    for (ElfW(Dyn)* d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: symtab = reinterpret_cast<ElfW(Sym)*>(resolvePtr(base, d->d_un.d_ptr)); break;
            case DT_STRTAB: strtab = reinterpret_cast<const char*>(resolvePtr(base, d->d_un.d_ptr)); break;
            case DT_JMPREL: jmprel = reinterpret_cast<ElfW(Rela)*>(resolvePtr(base, d->d_un.d_ptr)); break;
            case DT_PLTRELSZ: jmprelsz = d->d_un.d_val; break;
            case DT_RELAENT: relaent = d->d_un.d_val; break;
            default: break;
        }
    }
    if (!symtab || !strtab || !jmprel || jmprelsz == 0) return 0;
    if (relaent == 0) relaent = sizeof(ElfW(Rela));

    size_t count = jmprelsz / relaent;
    for (size_t i = 0; i < count; i++) {
        const ElfW(Rela)* r = reinterpret_cast<const ElfW(Rela)*>(
                reinterpret_cast<const char*>(jmprel) + i * relaent);
        unsigned type = ELF64_R_TYPE(r->r_info);
        if (type != R_AARCH64_JUMP_SLOT && type != R_AARCH64_GLOB_DAT) continue;
        size_t symIdx = ELF64_R_SYM(r->r_info);
        const char* name = strtab + symtab[symIdx].st_name;
        if (strncmp(name, g_prefix, g_prefixLen) != 0) continue;

        auto* slot = reinterpret_cast<void**>(base + r->r_offset);
        if (g_orig == nullptr) g_orig = *slot;
        g_slots.push_back({slot, nullptr});
        LOGI("%s: 命中 %s @slot %p", info->dlpi_name && info->dlpi_name[0] ? info->dlpi_name : "(main)", name, (void*)slot);
    }
    return 0;
}

} // namespace

int hookGotPrefix(const char* symPrefix, void* repl, void** origOut) {
    g_prefix = symPrefix;
    g_prefixLen = strlen(symPrefix);
    g_orig = nullptr;
    g_slots.clear();
    dl_iterate_phdr(callback, nullptr);

    for (auto& s : g_slots) s.repl = repl;
    rearmGotHooks();

    if (origOut) *origOut = g_orig;
    return (int) g_slots.size();
}

void rearmGotHooks() {
    for (auto& s : g_slots) {
        if (s.repl) patchSlot(s.addr, s.repl);
    }
}

int gotHookCount() { return (int) g_slots.size(); }
