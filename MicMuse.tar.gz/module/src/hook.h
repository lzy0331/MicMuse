#pragma once
#include <cstdint>

/**
 * 在 target 函数入口写一条 B 跳转，跳到 target 附近的 trampoline 页，
 * trampoline 里放绝对跳转到 replacement；同时提供一条回到原始函数（跳过被覆盖指令）的路径。
 *
 * 我们只覆盖 1 条指令(4 字节)，前一条若为 PC 相对/分支类指令则拒绝（调用方应回退）。
 * @return true 表示已挂钩，orig 返回可直接调用的原始入口
 */
bool installInlineHook(void* target, void* replacement, void** orig);
