#pragma once
#include <cstddef>
#include <cstdint>

namespace feeder {

/** 由 hook 侧告诉 feeder 目标录音格式（采样率/声道），只需在首次 read 时设置。 */
void setFormat(int sampleRate, int channels);

/** 启动后台线程连 127.0.0.1:35791 收流（幂等）。 */
void start();

void stop();

/** 当前是否已连上 App。 */
bool connected();

/** 从环形缓冲取数据，返回实际拷贝的字节数（不足部分由调用方补静音）。 */
size_t read(uint8_t* dst, size_t n);

}
