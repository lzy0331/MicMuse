#!/system/bin/sh
# 在 AndroidIDE 终端 / Linux 上构建 Zygisk 模块（需要 NDK 与 cmake）。
# 用法: NDK=/path/to/android-ndk ZYGISK_NDK=/path/to/ZygiskNDK sh build.sh
set -e
: "${NDK:?请设置 NDK 环境变量}"
: "${ZYGISK_NDK:?请设置 ZYGISK_NDK 环境变量}"
HERE=$(cd "$(dirname "$0")" && pwd)
OUT="$HERE/build/out"
rm -rf "$HERE/build"
mkdir -p "$OUT"
cmake -S "$HERE" -B "$HERE/build" \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-28 \
  -DZYGISK_NDK="$ZYGISK_NDK" -DCMAKE_BUILD_TYPE=Release
cmake --build "$HERE/build" -j"$(nproc 2>/dev/null || echo 4)"

SO="$HERE/build/libzygisk-micmuse.so"
[ -f "$SO" ] || SO="$HERE/build/zygisk-micmuse.so"
[ -f "$SO" ] || { echo "构建产物没找到"; exit 1; }

# 组装模块目录结构
mkdir -p "$OUT/zygisk"
cp "$SO" "$OUT/zygisk/arm64.so"
cp "$HERE/module.prop" "$OUT/"
cp "$HERE/targets.conf" "$OUT/"
echo "模块目录: $OUT"
