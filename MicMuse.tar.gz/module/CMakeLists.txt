cmake_minimum_required(VERSION 3.22)
project(micmuse CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# zygisk.hpp 所在目录（ZygiskNDK），通过 -DZYGISK_NDK=<dir> 传入；自动探测常见布局
if(NOT DEFINED ZYGISK_NDK)
    message(FATAL_ERROR "请传入 -DZYGISK_NDK=<ZygiskNDK 目录>")
endif()
find_path(ZYGISK_INCLUDE zygisk.hpp
        PATHS ${ZYGISK_NDK}/module/jni/include ${ZYGISK_NDK}/include ${ZYGISK_NDK}
        NO_DEFAULT_PATH)
if(NOT ZYGISK_INCLUDE)
    message(FATAL_ERROR "在 ${ZYGISK_NDK} 下找不到 zygisk.hpp")
endif()

include_directories(${ZYGISK_INCLUDE} ${CMAKE_SOURCE_DIR}/src)

add_library(zygisk-micmuse SHARED
        src/main.cpp
        src/feeder.cpp
        src/hook.cpp
        src/gothook.cpp)

target_compile_options(zygisk-micmuse PRIVATE -fvisibility=hidden -Wall -O2)
target_link_libraries(zygisk-micmuse log dl)
set_target_properties(zygisk-micmuse PROPERTIES PREFIX "")
